---
id: BP-3.1
title: Правила частоты и каналов касаний
status: To Do
assignee: []
created_date: '2026-10-19 19:07'
updated_date: '2026-10-19 22:34'
labels:
  - stage:A
  - layer:support
dependencies: []
parent_task_id: BP-3
ordinal: 22000
---

## Description

<!-- SECTION:DESCRIPTION:BEGIN -->
Маркетинг пересматривает частоту и каналы касаний, чтобы напоминания не вели к отпискам и жалобам.

### UserStory
Как гость, я хочу получать напоминания о скидке не чаще оговорённого и удобным каналом, чтобы не отписываться от рассылки.

### JobStory
- Когда запускаются касания акции, хочу ограничить их частоту, чтобы гость не отписался.

### Параметры
- **Вход:** Текущие триггерные касания
- **Управление:** Отписки соблюдаются (ФТ-6); Лимит частоты [УТОЧНИТЬ у CPO продукта]
- **Выход:** Частота и каналы касаний (BP-12.2)
- **Механизм:** Маркетинг

### Процесс
- Маркетинг: Пересматривает текущие касания
- Маркетинг: Задаёт частоту и каналы [УТОЧНИТЬ у CPO продукта]
- TeamA: Применяет правила к касаниям

### BPMN
```mermaid
flowchart LR
  subgraph L1["Маркетинг"]
    S((" "))
    N1["Пересматривает текущие касания"]
    N2["Задаёт частоту и каналы [УТОЧНИТЬ у CPO продукта]"]
  end
  subgraph L2["TeamA"]
    N3["Применяет правила к касаниям"]
    E(((" ")))
  end
  S --> N1
  N1 --> N2
  N2 --> N3
  N3 --> E
  classDef start fill:#fff,stroke:#2f6b2a,stroke-width:2px
  classDef stop fill:#fff,stroke:#1c1c1c,stroke-width:4px
  classDef gw fill:#fff8e6,stroke:#b7791f
  classDef ask color:#c0392b,stroke:#c0392b
  class S start
  class E stop
  class N2 ask
  style L1 fill:#faf9f6,stroke:#d8d4cb
  style L2 fill:#ffffff,stroke:#d8d4cb
```

### HowToDemo
1. Правила касаний утверждены: частота и каналы
2. Касания в окне скидки идут по этим правилам, отписки соблюдаются
<!-- SECTION:DESCRIPTION:END -->
