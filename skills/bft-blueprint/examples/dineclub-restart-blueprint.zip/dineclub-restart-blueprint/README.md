# Перезапуск акции DineClub — «билет Acme Tickets = скидка 10%»

Service Blueprint инициативы `dineclub-restart` — проект [Backlog.md](https://github.com/MrLesk/Backlog.md). Доска: `backlog board` или `backlog browser`; страница карты — `blueprint.html` в архиве или `dineclub-restart-map.html` после сборки.

<!-- BFT-BLUEPRINT START -->
# Service Blueprint «Перезапуск акции DineClub — «билет Acme Tickets = скидка 10%»»

Проект автономен: всё для работы — в этой папке, ничего ставить не нужно, кроме python3.
Данные — проект [Backlog.md](https://github.com/MrLesk/Backlog.md) (формат 1.54); эпик `dineclub-restart`, источник — БФТ `dineclub-restart.md`.

## Что здесь

| Путь | Что |
|---|---|
| `./backlog.py` | CLI Backlog.md, встроенный (`python3 backlog.py …` на Windows). Начни с `./backlog.py instructions overview` |
| `./blueprint.py` | `lint` — проверка карты, `build` — страница `dineclub-restart-map.html` и архив `dineclub-restart-blueprint.zip`, `check` — без записи |
| `backlog/tasks/` | задачи: «Что делаем» и их подзадачи «Как это работает» |
| `backlog/docs/` | документы: «Карта» (команды, вопросы), «История» (этапы, шаги, экраны), `screens/` — требования к экранам |
| `contracts/` | контракты стыков `C-N.md`: кто кого вызывает, поля с источником в БФТ, пример ответа, ошибки, Sequence, цепочка, данные. Шаблон — `.blueprint/templates/contract.md`, проверка — `./blueprint.py contracts` |
| `prototype/` | прототип для заказчика: `spec.md` — план показа (правится), остальное собирает `./blueprint.py prototype build`: `web/` — пошаговый показ, `api/main.py` — MockAPI по контрактам, `docker-compose.yml`. Правила — `.blueprint/rules/prototype.md` |
| `backlog/assets/screens/` | картинки экранов: `<ID>.svg` пишет `./blueprint.py build` из таблицы «Экраны» «Истории»; свой макет — `<ID>.png` рядом |
| `.blueprint/rules/` | правила: `backlog_rules.md` — карта, `screen_notes.md` — экраны, `story_line.md` — история, `contracts.md` — контракты, `prototype.md` — прототип |
| `.blueprint/vendor/` | `mermaid.min.js` — страница рисует схемы BPMN без сети |
| `blueprint.html`, `dineclub-restart-map.html` | страница карты: текст — только из этих файлов, картинки и mermaid — из папки. Правой кнопкой — замечание, «?» — ответить на вопрос, «!» — файлы, откуда собрано; промпт агенту — кнопкой «Скопировать промпт» |

Установлен npm-пакет `backlog.md` — его `backlog board` и `backlog browser` работают с теми же файлами.

## Карта — это задачи и документы

- **Что делаем** — задача с меткой `stage:<этап>` и видом (`создать`, `доработать`, `используем`, `уточнить`), исполнитель — команда `@id` из «Карты» (неизвестна — метки `кандидат:<id>`). Описание: зачем; строка `Требования БФТ: …`; разделы `### ASIS`, `### GAP`, `### TOBE`, `### HowToDemo`, по желанию `### Дополнительно`. Чеклист приемки — критерии `--ac`.
- **Как это работает** — подзадача (`-p BP-N`) с метками `stage:<этап>` и `layer:employee|technology|backstage|support`. Описание: суть; `### UserStory` «Как <роль>, я хочу …, чтобы …»; `### JobStory` — список «- Когда …, хочу …, чтобы …»; `### Параметры` (`- **Вход:** …`, `- **Управление:** …`, `- **Выход:** …`, `- **Механизм:** …`, значения через `;`, ссылка `(BP-8.1)` — связь с карточкой); `### Процесс` — шаги `- Участник: действие`, развилка `- ? вопрос` и под ней ветки `  - да → Участник: действие` или `  - нет → конец`; `### HowToDemo`. У `layer:backstage` — только суть, `### Параметры`, `### Процесс` и `### Данные` (`- что — откуда`, по желанию), без UserStory, JobStory и HowToDemo. Название карточки — «<кто> <что делает>, чтобы <результат>». Жёстко: у карточки нет команды (`-a ""`) — это целевая картинка глазами пользователя, одно событие сервиса — одна карточка; карточка — регулярный процесс работающего сервиса, не разовая задача команды («переключает», «переверстывает», «настраивает»); в Backstage участники и механизм — технологические компоненты, никогда не команды. Блок `### BPMN` не пиши — его собирает `./blueprint.py build` из процесса.
- **Требования к экрану** — документ `F3 · Название` в `backlog/docs/screens/`: `# Название`, картинки `![…](../../assets/screens/F3.svg)`, вкладки `## Product`, `## Design`, `## Functions`, заметки `### …` с `Источник: ФТ-1`.

Задачи без метки `stage:` на карте не показываются — это обычная работа: план реализации, баги.

## Правила

1. Задачи и документы меняй только через `./backlog.py`: файлы руками не правь.
2. Факты — только из БФТ и ответов PO. Неизвестное — `[УТОЧНИТЬ у {кого}]` в тексте и строка в «Вопросах» документа «Карта».
3. Названия и суть — без API, протоколов, таблиц БД: это высота БФТ. Метод, поля и ошибки стыка — в `contracts/C-N.md`, не в карточке.
4. После правок: `./blueprint.py lint` → 0 ошибок, `./blueprint.py contracts` → 0 ошибок, затем `./blueprint.py build`.

## Частые действия

```bash
./backlog.py task list -l stage:F --plain                       # задачи этапа
./backlog.py task view BP-16 --plain                            # постановка целиком
./backlog.py task edit BP-16 --ac "Отказ — с понятной причиной"  # добавить критерий приемки
./backlog.py task edit BP-16 --add-ref https://jira.example.com/browse/DEMO-16 --notes "Ход работ"
./backlog.py task create "Проверка часового пояса" -p BP-16 -a "" -l "stage:F,layer:backstage" --no-dod-defaults \
  -d $'Суть.\n\n### UserStory\nКак …, я хочу …, чтобы …\n\n### JobStory\n- Когда …, хочу …, чтобы …\n\n### Параметры\n- **Вход:** …\n- **Управление:** …\n- **Выход:** …\n- **Механизм:** …\n\n### Процесс\n- Участник: действие\n- ? Вопрос?\n  - да → Участник: действие\n  - нет → конец\n\n### HowToDemo\n1. …\n2. …'
./backlog.py doc view doc-1                                     # команды и вопросы
./backlog.py doc update doc-1 --content "$(cat карта.md)"        # правка документа целиком
./blueprint.py lint && ./blueprint.py build
```
<!-- BFT-BLUEPRINT END -->
