window.SPEC = {
 "apps": {
  "admin": "админка",
  "backend": "за кадром",
  "client": "клиент",
  "external": "внешняя сторона",
  "staff": "сотрудник"
 },
 "contracts": {
  "C-1": {
   "boundary": "frontend-backend",
   "callee": "Каталог UnitB",
   "caller": "Витрина",
   "cards": [
    "BP-2.1",
    "BP-5.1",
    "BP-6.1",
    "BP-8.1",
    "BP-9.1",
    "BP-11.1"
   ],
   "chain": [
    {
     "Вход": "venue_id, filters",
     "Выход": "candidates{id, name, walk_minutes}",
     "Кто": "Каталог UnitB",
     "Что делает": "отбирает участников акции у площадки, без радиуса",
     "Шаг": "1"
    },
    {
     "Вход": "candidates, filters",
     "Выход": "items{id, name, walk_minutes, rating, discount}, total",
     "Кто": "Каталог UnitB",
     "Что делает": "ранжирует: ближние × рейтинг",
     "Шаг": "2"
    }
   ],
   "data": [],
   "errors": [
    {
     "Когда": "площадки нет в каталоге — витрина показывает полный список (ФТ-3)",
     "Код": "VENUE_NOT_FOUND",
     "Статус": "404"
    }
   ],
   "example": {
    "items": [
     {
      "discount": 10,
      "id": "r-12",
      "name": "Сад",
      "rating": 4.7,
      "walk_minutes": 6
     }
    ],
    "total": 48
   },
   "id": "C-1",
   "op": "GET /v1/restaurants",
   "request": [
    {
     "Где": "query",
     "Источник": "ФТ-3",
     "Обяз.": "нет",
     "Поле": "venue_id",
     "Тип": "string"
    },
    {
     "Где": "query",
     "Источник": "ФТ-11, ИТ-7",
     "Обяз.": "нет",
     "Поле": "filters",
     "Тип": "string"
    },
    {
     "Где": "query",
     "Источник": "ИТ-3",
     "Обяз.": "нет",
     "Поле": "limit",
     "Тип": "integer"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-3",
     "Поле": "items",
     "Тип": "array"
    },
    {
     "Источник": "ФТ-3",
     "Поле": "items.id",
     "Тип": "string"
    },
    {
     "Источник": "ФТ-3",
     "Поле": "items.name",
     "Тип": "string"
    },
    {
     "Источник": "ИТ-4",
     "Поле": "items.walk_minutes",
     "Тип": "integer"
    },
    {
     "Источник": "НФТ-2",
     "Поле": "items.rating",
     "Тип": "number"
    },
    {
     "Источник": "ПТ-1",
     "Поле": "items.discount",
     "Тип": "integer"
    },
    {
     "Источник": "ИТ-3",
     "Поле": "total",
     "Тип": "integer"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "Витрина",
     "msg": "restaurants(venue_id, filters)",
     "to": "Каталог UnitB"
    },
    {
     "arrow": "-->",
     "from": "Каталог UnitB",
     "msg": "items, total",
     "to": "Витрина"
    }
   ],
   "title": "Витрина показывает рестораны у площадки билета"
  },
  "C-2": {
   "boundary": "frontend-backend",
   "callee": "Каталог UnitB",
   "caller": "Витрина",
   "cards": [
    "BP-10.1",
    "BP-2.1"
   ],
   "chain": [],
   "data": [],
   "errors": [
    {
     "Когда": "ресторан вышел из акции",
     "Код": "RESTAURANT_NOT_FOUND",
     "Статус": "404"
    }
   ],
   "example": {
    "hours": "12:00–23:00",
    "id": "r-12",
    "name": "Сад",
    "promo": {
     "discount": 10,
     "window_days": 7
    },
    "walk_minutes": 6
   },
   "id": "C-2",
   "op": "GET /v1/restaurants/{restaurant_id}",
   "request": [
    {
     "Где": "path",
     "Источник": "ФТ-3",
     "Обяз.": "да",
     "Поле": "restaurant_id",
     "Тип": "string"
    },
    {
     "Где": "query",
     "Источник": "ИТ-4",
     "Обяз.": "нет",
     "Поле": "venue_id",
     "Тип": "string"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-3",
     "Поле": "id",
     "Тип": "string"
    },
    {
     "Источник": "ФТ-3",
     "Поле": "name",
     "Тип": "string"
    },
    {
     "Источник": "ФТ-4",
     "Поле": "hours",
     "Тип": "string"
    },
    {
     "Источник": "ИТ-4",
     "Поле": "walk_minutes",
     "Тип": "integer"
    },
    {
     "Источник": "ПТ-1",
     "Поле": "promo.discount",
     "Тип": "integer"
    },
    {
     "Источник": "ФТ-1",
     "Поле": "promo.window_days",
     "Тип": "integer"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "Витрина",
     "msg": "restaurant(restaurant_id, venue_id)",
     "to": "Каталог UnitB"
    },
    {
     "arrow": "-->",
     "from": "Каталог UnitB",
     "msg": "карточка, блок акции",
     "to": "Витрина"
    }
   ],
   "title": "Гость открывает карточку ресторана"
  },
  "C-3": {
   "boundary": "external",
   "callee": "TeamA",
   "caller": "Приложение-сканер",
   "cards": [
    "BP-15.1",
    "BP-16.1"
   ],
   "chain": [
    {
     "Вход": "barcode",
     "Выход": "ticket{ticket_status, event_date}",
     "Кто": "Acme Tickets",
     "Что делает": "отдаёт статус билета и дату мероприятия",
     "Шаг": "1"
    },
    {
     "Вход": "barcode",
     "Выход": "used",
     "Кто": "Хранилище билетов",
     "Что делает": "отвечает, давал ли билет скидку",
     "Шаг": "2"
    },
    {
     "Вход": "ticket.ticket_status, ticket.event_date, used",
     "Выход": "status, reason",
     "Кто": "TeamA",
     "Что делает": "проверяет: активен, не использован, ≤ 7 дней",
     "Шаг": "3"
    },
    {
     "Вход": "status, barcode, restaurant_id",
     "Выход": "discount",
     "Кто": "TeamA",
     "Что делает": "при «валиден» помечает билет «использован» и считает скидку",
     "Шаг": "4"
    }
   ],
   "data": [],
   "errors": [
    {
     "Когда": "штрихкод не найден у Acme Tickets",
     "Код": "TICKET_NOT_FOUND",
     "Статус": "404"
    },
    {
     "Когда": "билет уже дал скидку (ФТ-1)",
     "Код": "ALREADY_USED",
     "Статус": "409"
    },
    {
     "Когда": "с мероприятия прошло больше 7 дней (ФТ-1)",
     "Код": "WINDOW_EXPIRED",
     "Статус": "422"
    },
    {
     "Когда": "билет возвращён или мероприятие отменено (ФТ-15)",
     "Код": "TICKET_RETURNED",
     "Статус": "422"
    }
   ],
   "example": {
    "discount": 10,
    "reason": null,
    "status": "valid"
   },
   "id": "C-3",
   "op": "POST /v1/tickets/{barcode}/verify",
   "request": [
    {
     "Где": "path",
     "Источник": "ФТ-1, извне: штрихкод с билета Acme Tickets",
     "Обяз.": "да",
     "Поле": "barcode",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-1",
     "Обяз.": "да",
     "Поле": "restaurant_id",
     "Тип": "string"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-1",
     "Поле": "status",
     "Тип": "string"
    },
    {
     "Источник": "ПТ-1",
     "Поле": "discount",
     "Тип": "integer"
    },
    {
     "Источник": "ФТ-15",
     "Поле": "reason",
     "Тип": "string"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "Приложение-сканер",
     "msg": "verify(barcode, restaurant_id)",
     "to": "TeamA"
    },
    {
     "arrow": "->",
     "from": "TeamA",
     "msg": "статус билета(barcode)",
     "to": "Acme Tickets"
    },
    {
     "arrow": "-->",
     "from": "Acme Tickets",
     "msg": "ticket_status, event_date",
     "to": "TeamA"
    },
    {
     "arrow": "->",
     "from": "TeamA",
     "msg": "отметки скидок по barcode",
     "to": "Хранилище билетов"
    },
    {
     "arrow": "-->",
     "from": "Хранилище билетов",
     "msg": "used",
     "to": "TeamA"
    },
    {
     "arrow": "-->",
     "from": "TeamA",
     "msg": "status, discount, reason",
     "to": "Приложение-сканер"
    }
   ],
   "title": "Официант сканирует билет — сервис отвечает «валиден» или «отказ»"
  },
  "C-4": {
   "boundary": "service-service",
   "callee": "DineClub",
   "caller": "Приложение-сканер",
   "cards": [
    "BP-17.1",
    "BP-18.1"
   ],
   "chain": [
    {
     "Вход": "barcode, restaurant_id, photo, discount",
     "Выход": "receipt_id, compensation",
     "Кто": "DineClub",
     "Что делает": "фиксирует компенсацию ресторану",
     "Шаг": "1"
    },
    {
     "Вход": "barcode, discount",
     "Выход": "notified",
     "Кто": "Acme Tickets",
     "Что делает": "получает уведомление: гость, скидка, когда (ФТ-14)",
     "Шаг": "2"
    }
   ],
   "data": [],
   "errors": [
    {
     "Когда": "чек по этому билету уже принят",
     "Код": "RECEIPT_EXISTS",
     "Статус": "409"
    },
    {
     "Когда": "лимит компенсаций ресторана исчерпан [УТОЧНИТЬ у DineClub]",
     "Код": "LIMIT_EXCEEDED",
     "Статус": "422"
    }
   ],
   "example": {
    "compensation": "accepted",
    "receipt_id": "rc-301"
   },
   "id": "C-4",
   "op": "POST /v1/receipts",
   "request": [
    {
     "Где": "body",
     "Источник": "ФТ-14",
     "Обяз.": "да",
     "Поле": "barcode",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-14",
     "Обяз.": "да",
     "Поле": "restaurant_id",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-14",
     "Обяз.": "да",
     "Поле": "photo",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ПТ-1",
     "Обяз.": "да",
     "Поле": "discount",
     "Тип": "integer"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-14",
     "Поле": "receipt_id",
     "Тип": "string"
    },
    {
     "Источник": "[УТОЧНИТЬ у DineClub]",
     "Поле": "compensation",
     "Тип": "string"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "Приложение-сканер",
     "msg": "receipt(barcode, restaurant_id, photo, discount)",
     "to": "DineClub"
    },
    {
     "arrow": "->",
     "from": "DineClub",
     "msg": "уведомление о списании(гость, скидка, когда)",
     "to": "Acme Tickets"
    },
    {
     "arrow": "-->",
     "from": "Acme Tickets",
     "msg": "принято",
     "to": "DineClub"
    },
    {
     "arrow": "-->",
     "from": "DineClub",
     "msg": "receipt_id, compensation",
     "to": "Приложение-сканер"
    }
   ],
   "title": "Фото чека — компенсация ресторану и уведомление о списании"
  },
  "C-5": {
   "boundary": "service-db",
   "callee": "Хранилище билетов",
   "caller": "TeamA",
   "cards": [
    "BP-16.1",
    "BP-18.1"
   ],
   "chain": [],
   "data": [
    {
     "Источник": "ФТ-1",
     "Какие данные нужны": "штрихкод, ресторан, когда дана скидка — одна покупка, одна скидка",
     "Хранилище": "Хранилище билетов"
    },
    {
     "Источник": "ФТ-15",
     "Какие данные нужны": "возврат, отмена, перенос билета",
     "Хранилище": "Хранилище билетов"
    },
    {
     "Источник": "[УТОЧНИТЬ у DineClub]",
     "Какие данные нужны": "сколько компенсаций у ресторана",
     "Хранилище": "Хранилище билетов"
    }
   ],
   "errors": [],
   "example": null,
   "id": "C-5",
   "op": "",
   "request": [],
   "response": [],
   "sequence": [],
   "title": "Что сервис проверки билетов хранит о скидках"
  },
  "C-6": {
   "boundary": "service-service",
   "callee": "Каталог UnitB",
   "caller": "DineClub",
   "cards": [
    "BP-1.1",
    "BP-2.1"
   ],
   "chain": [
    {
     "Вход": "name, address",
     "Выход": "rating",
     "Кто": "Справочник рейтингов",
     "Что делает": "отдаёт рейтинг из квартальной выгрузки (НФТ-2)",
     "Шаг": "1"
    },
    {
     "Вход": "partner_id, address, hours, rating",
     "Выход": "restaurant_id, venues",
     "Кто": "Каталог UnitB",
     "Что делает": "заводит участника, считает площадки рядом",
     "Шаг": "2"
    },
    {
     "Вход": "hours, restaurant_id",
     "Выход": "published",
     "Кто": "Каталог UnitB",
     "Что делает": "публикует, если часы работы есть",
     "Шаг": "3"
    }
   ],
   "data": [],
   "errors": [
    {
     "Когда": "нет часов работы — в каталог не публикуется (ФТ-4)",
     "Код": "HOURS_MISSING",
     "Статус": "422"
    },
    {
     "Когда": "ресторан уже в каталоге",
     "Код": "PARTNER_EXISTS",
     "Статус": "409"
    }
   ],
   "example": {
    "published": true,
    "rating": 4.7,
    "restaurant_id": "r-12"
   },
   "id": "C-6",
   "op": "POST /v1/restaurants",
   "request": [
    {
     "Где": "body",
     "Источник": "ФТ-19, извне: ID партнёра в DineClub",
     "Обяз.": "да",
     "Поле": "partner_id",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-3",
     "Обяз.": "да",
     "Поле": "name",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-3",
     "Обяз.": "да",
     "Поле": "address",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-4",
     "Обяз.": "да",
     "Поле": "hours",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "[УТОЧНИТЬ у DineClub]",
     "Обяз.": "да",
     "Поле": "city",
     "Тип": "string"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-3",
     "Поле": "restaurant_id",
     "Тип": "string"
    },
    {
     "Источник": "НФТ-2",
     "Поле": "rating",
     "Тип": "number"
    },
    {
     "Источник": "ФТ-4",
     "Поле": "published",
     "Тип": "boolean"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "DineClub",
     "msg": "restaurant(partner_id, name, address, hours, city)",
     "to": "Каталог UnitB"
    },
    {
     "arrow": "->",
     "from": "Каталог UnitB",
     "msg": "рейтинг(name, address)",
     "to": "Справочник рейтингов"
    },
    {
     "arrow": "-->",
     "from": "Справочник рейтингов",
     "msg": "rating",
     "to": "Каталог UnitB"
    },
    {
     "arrow": "-->",
     "from": "Каталог UnitB",
     "msg": "restaurant_id, rating, published",
     "to": "DineClub"
    }
   ],
   "title": "Подключённый ресторан попадает в каталог участников"
  },
  "C-7": {
   "boundary": "external",
   "callee": "Email / SMS",
   "caller": "Триггеры касаний",
   "cards": [
    "BP-12.2",
    "BP-12.1",
    "BP-13.1",
    "BP-14.1"
   ],
   "chain": [],
   "data": [],
   "errors": [
    {
     "Когда": "гость отписан — касание не уходит (ФТ-6)",
     "Код": "UNSUBSCRIBED",
     "Статус": "409"
    },
    {
     "Когда": "у гостя нет ни email, ни телефона [УТОЧНИТЬ у CPO продукта]",
     "Код": "NO_CHANNEL",
     "Статус": "422"
    }
   ],
   "example": {
    "channel": "email",
    "status": "sent"
   },
   "id": "C-7",
   "op": "POST /v1/touches",
   "request": [
    {
     "Где": "body",
     "Источник": "ФТ-6, извне: гость Acme Tickets",
     "Обяз.": "да",
     "Поле": "guest_id",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-16, ФТ-6",
     "Обяз.": "да",
     "Поле": "kind",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-16",
     "Обяз.": "да",
     "Поле": "event_date",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ПТ-1",
     "Обяз.": "да",
     "Поле": "discount",
     "Тип": "integer"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-6",
     "Поле": "status",
     "Тип": "string"
    },
    {
     "Источник": "[УТОЧНИТЬ у CPO продукта]",
     "Поле": "channel",
     "Тип": "string"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "Триггеры касаний",
     "msg": "touch(guest_id, kind, event_date, discount)",
     "to": "Email / SMS"
    },
    {
     "arrow": "-->",
     "from": "Email / SMS",
     "msg": "status, channel",
     "to": "Триггеры касаний"
    }
   ],
   "title": "Триггер касаний отправляет напоминание через внешний канал: email, SMS или push"
  },
  "C-8": {
   "boundary": "external",
   "callee": "Аналитика",
   "caller": "Витрина",
   "cards": [
    "BP-19.1",
    "BP-5.1",
    "BP-7.1",
    "BP-8.1",
    "BP-10.1",
    "BP-18.1"
   ],
   "chain": [],
   "data": [],
   "errors": [
    {
     "Когда": "событие не из воронки «билет → ресторан → скидка» [УТОЧНИТЬ у UnitB]",
     "Код": "UNKNOWN_EVENT",
     "Статус": "422"
    }
   ],
   "example": {
    "accepted": true
   },
   "id": "C-8",
   "op": "POST /v1/events",
   "request": [
    {
     "Где": "body",
     "Источник": "ФТ-9",
     "Обяз.": "да",
     "Поле": "event",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-9",
     "Обяз.": "да",
     "Поле": "stage",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "ФТ-9",
     "Обяз.": "нет",
     "Поле": "utm",
     "Тип": "string"
    },
    {
     "Где": "body",
     "Источник": "[УТОЧНИТЬ у UnitB]",
     "Обяз.": "нет",
     "Поле": "ticket_id",
     "Тип": "string"
    }
   ],
   "response": [
    {
     "Источник": "ФТ-9",
     "Поле": "accepted",
     "Тип": "boolean"
    }
   ],
   "sequence": [
    {
     "arrow": "->",
     "from": "Витрина",
     "msg": "event(event, stage, utm, ticket_id)",
     "to": "Аналитика"
    },
    {
     "arrow": "-->",
     "from": "Аналитика",
     "msg": "accepted",
     "to": "Витрина"
    }
   ],
   "title": "Витрина, письма и DineClub отдают события воронки в аналитику без ручного логирования"
  }
 },
 "epic": "dineclub-restart",
 "screens": {
  "A1": {
   "contour": "Приложение-сканер",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Сканер билетов"
    ],
    [
     "ok",
     "Подключён"
    ],
    [
     "text",
     "Инструкция, FAQ и поддержка — внутри"
    ]
   ],
   "id": "A1",
   "view": "основной"
  },
  "B1": {
   "contour": "Витрина",
   "device": "web",
   "elements": [
    [
     "hdr",
     "✓ Билет куплен"
    ],
    [
     "offer",
     "Скидка 10% в ресторанах рядом"
    ],
    [
     "tiles"
    ],
    [
     "cta",
     "Выбрать ресторан"
    ]
   ],
   "id": "B1",
   "view": "основной"
  },
  "C1": {
   "contour": "Email",
   "device": "mail",
   "elements": [
    [
     "from",
     "Acme Tickets"
    ],
    [
     "hdr",
     "Ваш билет Acme Tickets"
    ],
    [
     "text",
     "Детали заказа"
    ],
    [
     "offer",
     "Скидка 10% в DineClub"
    ],
    [
     "cta",
     "Выбрать ресторан"
    ],
    [
     "cta2",
     "Забронировать"
    ]
   ],
   "id": "C1",
   "view": "основной"
  },
  "D1": {
   "contour": "Витрина",
   "device": "web",
   "elements": [
    [
     "hdr",
     "Все рестораны"
    ],
    [
     "chips",
     [
      "Персоны",
      "Метро",
      "+3"
     ]
    ],
    [
     "rowsOffer",
     3
    ]
   ],
   "id": "D1",
   "view": "основной"
  },
  "D2": {
   "contour": "Витрина",
   "device": "web",
   "elements": [
    [
     "img"
    ],
    [
     "offer",
     "−10% по билету"
    ],
    [
     "kv",
     "Окно",
     "7 дней"
    ],
    [
     "kv",
     "Пешком",
     "от площадки"
    ],
    [
     "kv",
     "Часы",
     "работы"
    ]
   ],
   "id": "D2",
   "view": "основной"
  },
  "E1": {
   "contour": "Оповещение",
   "device": "lock",
   "elements": [
    [
     "notif",
     "Acme Tickets",
     "Мероприятие завтра",
     "Скидка 10% в ресторанах рядом"
    ]
   ],
   "id": "E1",
   "view": "основной"
  },
  "E2": {
   "contour": "Email или SMS",
   "device": "lock",
   "elements": [
    [
     "notif",
     "Acme Tickets",
     "Скидка 10% ещё действует",
     "Окно — 7 дней после мероприятия"
    ],
    [
     "link",
     "Отписаться"
    ]
   ],
   "id": "E2",
   "view": "основной"
  },
  "F1": {
   "contour": "Электронный билет",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Ваш билет"
    ],
    [
     "text",
     "Билет на мероприятие"
    ],
    [
     "barcode"
    ],
    [
     "offer",
     "Скидка 10% в DineClub"
    ]
   ],
   "id": "F1",
   "view": "основной"
  },
  "F2": {
   "contour": "Приложение-сканер",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Сканер билетов"
    ],
    [
     "camera"
    ],
    [
     "cta",
     "Сканировать"
    ]
   ],
   "id": "F2",
   "view": "основной"
  },
  "F3": {
   "contour": "Приложение-сканер",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Сканер билетов"
    ],
    [
     "ok",
     "Скидка 10%"
    ],
    [
     "cta",
     "Сфотографировать чек"
    ]
   ],
   "id": "F3",
   "view": "основной"
  },
  "F4": {
   "contour": "Приложение-сканер",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Сканер билетов"
    ],
    [
     "no",
     "Отказ"
    ],
    [
     "text",
     "Билет использован, вне окна или возвращён"
    ]
   ],
   "id": "F4",
   "view": "альтернативный"
  },
  "F5": {
   "contour": "Приложение-сканер",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Сканер билетов"
    ],
    [
     "ok",
     "Чек сохранён"
    ],
    [
     "text",
     "Компенсация ресторану зафиксирована"
    ]
   ],
   "id": "F5",
   "view": "основной"
  },
  "F6": {
   "contour": "Приложение-сканер",
   "device": "phone",
   "elements": [
    [
     "hdr",
     "Инструкция и FAQ"
    ],
    [
     "rows",
     3
    ],
    [
     "cta2",
     "Поддержка"
    ]
   ],
   "id": "F6",
   "view": "основной"
  }
 },
 "steps": [
  {
   "app": "backend",
   "calls": [
    "C-6"
   ],
   "data": [],
   "fail": {
    "code": "HOURS_MISSING",
    "screen": "—"
   },
   "id": "C-6",
   "inputs": {
    "address": "Москва, Тверская, 12",
    "city": "Москва",
    "hours": "12:00–23:00",
    "name": "Сад",
    "partner_id": "dc-77"
   },
   "note": "DineClub подключил ресторан — каталог UnitB заводит участника и берёт рейтинг из квартальной выгрузки",
   "ok": "",
   "persona": "DineClub",
   "screens": [],
   "show": [
    "restaurant_id",
    "rating",
    "published"
   ],
   "source": "",
   "stage": "A",
   "stageName": "Подготовка",
   "text": "",
   "title": "Подключённый ресторан попадает в каталог участников",
   "was": ""
  },
  {
   "app": "staff",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш11",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Ресторан-партнёр DineClub и официант",
   "screens": [
    "A1"
   ],
   "show": [],
   "source": "Изменение в UJM, подключение ресторана; БТ-4",
   "stage": "A",
   "stageName": "Подготовка",
   "text": "Подключаемся без брони и тяжёлой интеграции — получаем приложение-сканер и инструкцию.",
   "title": "Подключаемся без сложной интеграции",
   "was": "Подключение требовало тяжёлой интеграции и было привязано к брони."
  },
  {
   "app": "client",
   "calls": [
    "C-1"
   ],
   "data": [],
   "fail": {
    "code": "VENUE_NOT_FOUND",
    "screen": "—"
   },
   "id": "Ш2",
   "inputs": {},
   "note": "блок акции и полка ресторанов приходят из каталога UnitB по площадке билета — без радиуса, ближние и с рейтингом выше",
   "ok": "B1",
   "persona": "Гость Acme Tickets",
   "screens": [
    "B1"
   ],
   "show": [
    "items.id",
    "items.name",
    "items.walk_minutes",
    "items.rating",
    "items.discount",
    "total"
   ],
   "source": "How to demo, сценарий 1; ПТ-2",
   "stage": "B",
   "stageName": "Узнаю о скидке",
   "text": "Сразу после оплаты вижу: мне доступна скидка 10% и рестораны рядом.",
   "title": "Купил билет — и сразу вижу скидку",
   "was": "На странице после покупки об акции не было ни слова."
  },
  {
   "app": "staff",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш12",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Ресторан-партнёр DineClub и официант",
   "screens": [],
   "show": [],
   "source": "ПТ-2, ПТ-3",
   "stage": "B",
   "stageName": "Узнаю о скидке",
   "text": "О нас рассказывают гостю сразу после покупки, в письме и в напоминаниях — он видит нас среди ближайших к площадке.",
   "title": "Гости знают о скидке заранее",
   "was": "О скидке узнавали меньше 1% гостей — до ресторанов почти никто не доходил."
  },
  {
   "app": "client",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш3",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Гость Acme Tickets",
   "screens": [
    "C1"
   ],
   "show": [],
   "source": "How to demo, сценарий 2; ПТ-2",
   "stage": "C",
   "stageName": "Письмо",
   "text": "В письме с билетом — то же предложение и кнопка «Выбрать ресторан».",
   "title": "В письме — то же предложение",
   "was": "В письме была только кнопка «Забронировать в DineClub», без акцента на скидке."
  },
  {
   "app": "client",
   "calls": [
    "C-1",
    "C-2"
   ],
   "data": [],
   "fail": {
    "code": "VENUE_NOT_FOUND",
    "screen": "—"
   },
   "id": "Ш4",
   "inputs": {
    "restaurant_id": "r-12"
   },
   "note": "",
   "ok": "D2",
   "persona": "Гость Acme Tickets",
   "screens": [
    "D1",
    "D2"
   ],
   "show": [
    "items.id",
    "items.name",
    "items.walk_minutes",
    "items.rating",
    "items.discount",
    "total",
    "id",
    "name",
    "hours",
    "walk_minutes",
    "promo.discount",
    "promo.window_days"
   ],
   "source": "How to demo, сценарий 3; ПТ-3",
   "stage": "D",
   "stageName": "Выбор ресторана",
   "text": "Вижу все рестораны-участники, фильтрую под компанию; в карточке — скидка, путь пешком и часы работы.",
   "title": "Выбираю ресторан рядом с театром",
   "was": "Список обрезался по расстоянию, фильтров не было, в карточке ресторана не было акции."
  },
  {
   "app": "backend",
   "calls": [
    "C-7"
   ],
   "data": [],
   "fail": {
    "code": "UNSUBSCRIBED",
    "screen": "—"
   },
   "id": "C-7",
   "inputs": {
    "discount": "10",
    "event_date": "2026-11-14",
    "guest_id": "g-1024",
    "kind": "за 24 часа"
   },
   "note": "напоминание будит дата мероприятия, а не действие гостя; канал — email, SMS или push — пока открытый вопрос",
   "ok": "",
   "persona": "Триггеры касаний",
   "screens": [],
   "show": [
    "status",
    "channel"
   ],
   "source": "",
   "stage": "E",
   "stageName": "Не забываю",
   "text": "",
   "title": "Триггер касаний отправляет напоминание через внешний канал: email, SMS или push",
   "was": ""
  },
  {
   "app": "client",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш5",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Гость Acme Tickets",
   "screens": [
    "E1"
   ],
   "show": [],
   "source": "Изменение в UJM, касания; ПТ-2",
   "stage": "E",
   "stageName": "Не забываю",
   "text": "За сутки до мероприятия приходит напоминание о скидке.",
   "title": "Накануне мне напоминают",
   "was": "Напоминаний о скидке не было."
  },
  {
   "app": "client",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш6",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Гость Acme Tickets",
   "screens": [
    "E2"
   ],
   "show": [],
   "source": "Изменение в UJM, касания; ПТ-2",
   "stage": "E",
   "stageName": "Не забываю",
   "text": "Скидка действует ещё 7 дней — мне об этом напоминают; могу отписаться.",
   "title": "После мероприятия скидка ещё действует",
   "was": "После мероприятия о скидке никто не напоминал."
  },
  {
   "app": "client",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш7",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Гость Acme Tickets",
   "screens": [
    "F1"
   ],
   "show": [],
   "source": "How to demo, сценарий 4; ПТ-1",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "Прихожу в ресторан и показываю билет — бронь не нужна.",
   "title": "Прихожу и просто показываю билет",
   "was": "Скидка работала только по брони."
  },
  {
   "app": "client",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш8",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Гость Acme Tickets",
   "screens": [
    "F3"
   ],
   "show": [],
   "source": "How to demo, сценарий 4; ПТ-1",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "Официант сканирует штрихкод — скидка 10%. Если билет не подходит, он сразу видит понятную причину.",
   "title": "Официант сканирует — скидка моя",
   "was": "У официанта не было приложения, скидку привязывали к брони."
  },
  {
   "app": "staff",
   "calls": [
    "C-3"
   ],
   "data": [
    "C-5"
   ],
   "fail": {
    "code": "TICKET_NOT_FOUND",
    "screen": "F4"
   },
   "id": "Ш13",
   "inputs": {
    "barcode": "4600123456789",
    "restaurant_id": "r-12"
   },
   "note": "официант видит ответ сразу — за кадром TeamA спрашивает статус у Acme Tickets и проверяет, не давал ли билет скидку",
   "ok": "F3",
   "persona": "Ресторан-партнёр DineClub и официант",
   "screens": [
    "F2"
   ],
   "show": [
    "status",
    "discount",
    "reason"
   ],
   "source": "How to demo, сценарий 4; ПТ-4",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "Гость показывает билет — официант сканирует штрихкод.",
   "title": "Гость показывает билет — сканируем",
   "was": "Отдельного приложения для официанта не было."
  },
  {
   "app": "staff",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш14",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Ресторан-партнёр DineClub и официант",
   "screens": [
    "F3",
    "F4"
   ],
   "show": [],
   "source": "How to demo, сценарий 4; ПТ-4",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "Приложение сразу отвечает: скидка 10% или понятная причина отказа — без споров.",
   "title": "Приложение сразу даёт ответ",
   "was": ""
  },
  {
   "app": "staff",
   "calls": [
    "C-4"
   ],
   "data": [
    "C-5"
   ],
   "fail": {
    "code": "RECEIPT_EXISTS",
    "screen": "—"
   },
   "id": "Ш15",
   "inputs": {
    "barcode": "4600123456789",
    "discount": "10",
    "photo": "receipt-301.jpg",
    "restaurant_id": "r-12"
   },
   "note": "фото чека фиксирует компенсацию ресторану, Acme Tickets получает уведомление о списании (ФТ-14)",
   "ok": "F5",
   "persona": "Ресторан-партнёр DineClub и официант",
   "screens": [],
   "show": [
    "receipt_id",
    "compensation"
   ],
   "source": "How to demo, сценарий 4",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "Официант фотографирует чек — компенсация ресторану зафиксирована.",
   "title": "Фотографируем чек — получаем компенсацию",
   "was": ""
  },
  {
   "app": "staff",
   "calls": [],
   "data": [],
   "fail": {
    "code": "",
    "screen": ""
   },
   "id": "Ш16",
   "inputs": {},
   "note": "",
   "ok": "",
   "persona": "Ресторан-партнёр DineClub и официант",
   "screens": [
    "F6"
   ],
   "show": [],
   "source": "How to demo, сценарий 4; ПТ-4",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "Инструкция, частые вопросы и поддержка — в том же приложении.",
   "title": "Если что-то непонятно — помощь рядом",
   "was": ""
  },
  {
   "app": "backend",
   "calls": [
    "C-8"
   ],
   "data": [
    "C-5"
   ],
   "fail": {
    "code": "UNKNOWN_EVENT",
    "screen": "—"
   },
   "id": "C-8",
   "inputs": {
    "event": "ticket_scanned",
    "stage": "F",
    "ticket_id": "4600123456789",
    "utm": "email_after_purchase"
   },
   "note": "каждый шаг воронки — от показа блока до скидки в ресторане — сам попадает в отчёт, руками никто не логирует",
   "ok": "",
   "persona": "Витрина",
   "screens": [],
   "show": [
    "accepted"
   ],
   "source": "",
   "stage": "F",
   "stageName": "В ресторане",
   "text": "",
   "title": "Витрина, письма и DineClub отдают события воронки в аналитику без ручного логирования",
   "was": ""
  }
 ],
 "title": "dineclub-restart: Перезапуск акции DineClub — «билет Acme Tickets = скидка 10%»"
};
